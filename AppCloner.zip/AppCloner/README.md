# App 分身（AppCloner）

图形界面的 macOS 多开工具，可用于微信、QQ、企业微信等任意 App。支持 **Apple Silicon（M1–M4）和 Intel**（Universal 二进制），系统要求 macOS 13 及以上。

## 编译

```bash
xcode-select --install      # 只装一次，不需要完整 Xcode
cd AppCloner
chmod +x build.sh && ./build.sh
open AppCloner.app
```

## 使用

1. 把 App 拖进窗口（或点「选择 App…」），例如 `/Applications/WeChat.app`
2. 填好分身名称，点「生成分身」
3. 在列表里点「启动」。分身放在 `~/Applications/AppClones/`，也可以从启动台或 Spotlight 打开
4. 原版 App 更新后，列表里会提示，点「重建」就行。重建不会丢数据，因为 Bundle ID 不变

## 原理

复制原版 → 把 Bundle ID 改成 `原ID.cloneN` → 清除隔离属性 → ad-hoc 重新签名（Apple Silicon 必须做这一步）→ 注册到 LaunchServices。
系统会把分身当成另一个独立的 App，所以登录状态和聊天记录各自独立。

## 常见问题

- **提示 Operation not permitted**：打开「系统设置 → 隐私与安全性 → App 管理」，允许 AppCloner。
- **分身打不开或闪退**：勾选或取消「保留权限声明」后重建。
- **分身需要重新授权**：摄像头、麦克风、通知等权限要在分身里重新允许一次，这是正常的。
- **部分 App 不支持**：Electron 类 App 的数据目录不依赖 Bundle ID，分身可能和原版共用数据，或者只能开一个。
- **原版和分身图标一样**：可以在 Dock 里右键查看名字来区分。
- 微信等 App 的用户协议可能限制多开，请自行斟酌。
